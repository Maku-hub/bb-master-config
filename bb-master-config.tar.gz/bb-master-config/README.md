# buildbot-docker-example-config
example configuration for running buildbot in docker
